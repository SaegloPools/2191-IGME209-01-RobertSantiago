// PE3 - Functions.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "String.h"
#include <iostream>
using namespace std;
#include <string.h>

#include "functions.h"




//int _tmain(int argc, _TCHAR* argv[])
int main()
{
	PrintName();
	return 0;
}

void PrintName()
{
	cout << "\n Robert Santiago" << endl;
}